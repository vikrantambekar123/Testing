package resources;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Base.Base;

public class Utils extends Base
{
	public static LocalDate todayDate;
	public static String r;
	public static int latestr;
	
	public static String Todayd_Date()
	{
		 todayDate = LocalDate.now();     
		 String Today=todayDate.toString();
		 String Day[]=Today.split("-");
		 String today=Day[2].toString();
		 return today;
	}
	
	
	public static String Previous_Day()
	{
		todayDate = LocalDate.now();
//		System.out.println(todayDate.minusDays(1));
		 String Prev=todayDate.minusDays(1).toString();
		 String Previous[]=Prev.split("-");
		 String Yesterday=Previous[2].toString();
		 return Yesterday;
	}
	
	
	public static String Timing_Am_PM()
	{
		 Date date = new Date();
	     SimpleDateFormat formatTime = new SimpleDateFormat("hh.mm aa");
	     String time = formatTime.format(date); // changing the format of 'date'
	     System.out.println(time);
	     String [] data=time.split(" ");
	     String PM=data[1];
	     System.out.println(PM);
	     return PM;
	}
	
	
	public  static JavascriptExecutor JavascriptExecutor_Click(WebElement ele)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", ele); // For Clicking SElect ALl
		return js;
	}
	
	public  static JavascriptExecutor JavascriptExecutor_Highlightelement(WebElement ele)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: white; border: 2px solid red;');", ele); // For Clicking SElect ALl
		return js;
	}
	
	
	public static WebDriverWait Webdriverwait_elementtobeclickable(WebElement ele)
	{
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.elementToBeClickable(ele));
		return wait;
	}
	
	public static Select Selectby_VisibleText(WebElement ele,String text)
	{
		Select select=new Select(ele);
		select.selectByVisibleText(text);
		return select;
	}
	
	public static Month Currnet_Month()
	{
		LocalDate currentdate = LocalDate.now();
		Month currentMonth = currentdate.getMonth();
		return currentMonth;
	}
	
	
	
	public static void Time_After_Adding_6_MInutes()
	{
		Date date = new Date();
	    SimpleDateFormat formatTime = new SimpleDateFormat("hh.mm");
	    String time1 = formatTime.format(date); // changing the format of 'date'
      	DateTimeFormatter formatter = DateTimeFormat.forPattern("HH.mm");
        LocalTime time = formatter.parseLocalTime(time1);
        time = time.plusMinutes(6);
        System.out.println("Time After adding 6 Minute :-"+time);
        String time11=time.toString();
        String [] time2=time11.split("[:]");
        System.out.println(time2[0]);
		
	}
	
	
	    public static void Setdatetime() throws InterruptedException
	    {
			Date date = new Date();
		    SimpleDateFormat formatTime = new SimpleDateFormat("hh.mm");
		    String time1 = formatTime.format(date); // changing the format of 'date'
	      	DateTimeFormatter formatter = DateTimeFormat.forPattern("HH.mm");
	        LocalTime time = formatter.parseLocalTime(time1);
	        time = time.plusMinutes(6);
	        System.out.println("Time After adding 6 Minute :-"+time);
	        String time11=time.toString();
	        String [] time2=time11.split("[:]");
	        
	        int latesttime=Integer.parseInt(time2[1]);

	        
	        
	        //Iterating Over Time to select the Time in HH:MM Dropdown
	        
				WebElement data1=driver.findElement(By.xpath("//div[@class='dropdown-styled sc-kgoBCf ZIVjI']//div[@class='dropdownlabel "+time2[0]+" sc-jKJlTe YlOeE'][normalize-space()='"+time2[0]+"']"));

				if(data1.getText().toString().equalsIgnoreCase(time2[0]))		
				{
				System.out.println("----------------------------------");
				System.out.println(data1.getText().toString());	
//				System.out.println(time2[0]);
				System.out.println("----------------------------------");
				JavascriptExecutor js13 = (JavascriptExecutor) driver;
				js13.executeScript("arguments[0].setAttribute('style', 'background: white; border: 4px solid red;');",data1);
				data1.click();
				}
		   
		    
		        	for(int j=1;j<=12;j++)
		    		{
		        		List<WebElement>ele=driver.findElements(By.xpath("(//div[@id='undefined-item-"+j+"'])[2]"));
		        		Iterator<WebElement>it2=ele.iterator();
		        		while(it2.hasNext())
		        		{
		        			WebElement l=it2.next();
		        			String temp=l.getText().toString();
		        			System.out.println(temp);
	        				 

	        				int webtime = 0; // or any appllication default value try { number = Integer.parseInt(input); } catch (NumberFormatException nfe) { nfe.printStackTrace(); }
		        				System.out.println("Priting temo value :-"+temp);
		        				webtime = Integer.parseInt(temp); 
		        		
		        			System.out.println(webtime);
		        			if(webtime>=latesttime)
		        			{
		        				l.click();
		        				break;
		        			}
		     }
	    }
	}
	   
	    
	    
	
	    

	
	
	
	
	public static void main(String args[])
	{
		Utils u=new Utils();
		u.Currnet_Month();
	}
//	
	

}
